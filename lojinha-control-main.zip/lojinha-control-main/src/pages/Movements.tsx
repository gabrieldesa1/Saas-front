import { useState } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { mockMovements, mockProducts } from "@/data/mockData";
import { ArrowDownLeft, ArrowUpRight, Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";

export default function Movements() {
  const [open, setOpen] = useState(false);
  const [movementType, setMovementType] = useState<"entrada" | "saida">("entrada");
  const [searchQuery, setSearchQuery] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Movimentação registrada!",
      description: `A ${movementType} foi registrada com sucesso.`,
    });
    setOpen(false);
  };

  const filteredMovements = mockMovements.filter((movement) =>
    movement.productName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Movimentações</h1>
            <p className="text-muted-foreground mt-1">
              Registre entradas e saídas do estoque
            </p>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2 bg-primary hover:bg-primary/90">
                <Plus className="h-4 w-4" />
                Nova Movimentação
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Registrar Movimentação</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                {/* Movement Type Selector */}
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setMovementType("entrada")}
                    className={cn(
                      "flex items-center justify-center gap-2 p-4 rounded-xl border-2 transition-all",
                      movementType === "entrada"
                        ? "border-success bg-success/10 text-success"
                        : "border-border hover:border-success/50"
                    )}
                  >
                    <ArrowDownLeft className="h-5 w-5" />
                    <span className="font-medium">Entrada</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setMovementType("saida")}
                    className={cn(
                      "flex items-center justify-center gap-2 p-4 rounded-xl border-2 transition-all",
                      movementType === "saida"
                        ? "border-destructive bg-destructive/10 text-destructive"
                        : "border-border hover:border-destructive/50"
                    )}
                  >
                    <ArrowUpRight className="h-5 w-5" />
                    <span className="font-medium">Saída</span>
                  </button>
                </div>

                <div className="space-y-2">
                  <Label>Produto</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o produto" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockProducts.map((product) => (
                        <SelectItem key={product.id} value={product.id}>
                          {product.name} ({product.quantity} em estoque)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Quantidade</Label>
                  <Input type="number" min="1" placeholder="0" required />
                </div>

                <div className="space-y-2">
                  <Label>Motivo</Label>
                  <Textarea 
                    placeholder={
                      movementType === "entrada" 
                        ? "Ex: Reposição de estoque, devolução..." 
                        : "Ex: Venda, devolução ao fornecedor..."
                    }
                  />
                </div>

                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                    Cancelar
                  </Button>
                  <Button 
                    type="submit"
                    className={cn(
                      movementType === "entrada" 
                        ? "bg-success hover:bg-success/90 text-success-foreground" 
                        : ""
                    )}
                  >
                    Registrar {movementType === "entrada" ? "Entrada" : "Saída"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Buscar movimentações..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-secondary/50 border-0 focus-visible:ring-1 focus-visible:ring-primary"
          />
        </div>

        {/* Movements List */}
        <div className="rounded-2xl border border-border bg-card overflow-hidden animate-fade-in">
          <div className="divide-y divide-border">
            {filteredMovements.map((movement, index) => (
              <div 
                key={movement.id}
                className="flex items-center gap-4 p-4 transition-colors hover:bg-secondary/20"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <div className={cn(
                  "flex h-12 w-12 items-center justify-center rounded-xl",
                  movement.type === "entrada" 
                    ? "bg-success/20 text-success" 
                    : "bg-destructive/20 text-destructive"
                )}>
                  {movement.type === "entrada" ? (
                    <ArrowDownLeft className="h-6 w-6" />
                  ) : (
                    <ArrowUpRight className="h-6 w-6" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold truncate">{movement.productName}</p>
                    <Badge 
                      variant="secondary"
                      className={cn(
                        movement.type === "entrada" 
                          ? "bg-success/20 text-success" 
                          : "bg-destructive/20 text-destructive"
                      )}
                    >
                      {movement.type === "entrada" ? "Entrada" : "Saída"}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{movement.reason}</p>
                </div>
                <div className="text-right">
                  <p className={cn(
                    "text-xl font-bold",
                    movement.type === "entrada" ? "text-success" : "text-destructive"
                  )}>
                    {movement.type === "entrada" ? "+" : "-"}{movement.quantity}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {format(movement.date, "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
