import { useState, useMemo } from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { ProductsTable } from "@/components/products/ProductsTable";
import { ProductFilters } from "@/components/products/ProductFilters";
import { AddProductDialog } from "@/components/products/AddProductDialog";
import { mockProducts, mockCategories } from "@/data/mockData";
import { Package } from "lucide-react";

export default function Products() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const filteredProducts = useMemo(() => {
    return mockProducts.filter((product) => {
      const matchesSearch = 
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.sku.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = 
        selectedCategory === "all" || product.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Produtos</h1>
            <p className="text-muted-foreground mt-1">
              Gerencie todos os produtos do seu estoque
            </p>
          </div>
          <AddProductDialog categories={mockCategories} />
        </div>

        {/* Filters */}
        <ProductFilters
          categories={mockCategories}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
        />

        {/* Stats Bar */}
        <div className="flex items-center gap-6 text-sm">
          <div className="flex items-center gap-2">
            <Package className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">
              Mostrando <span className="font-medium text-foreground">{filteredProducts.length}</span> de{" "}
              <span className="font-medium text-foreground">{mockProducts.length}</span> produtos
            </span>
          </div>
        </div>

        {/* Table */}
        <ProductsTable products={filteredProducts} />
      </div>
    </AppLayout>
  );
}
